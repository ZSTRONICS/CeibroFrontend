export const requestPending = (type: string) => `${type}_PENDING`;
export const requestSuccess = (type: string) => `${type}_SUCCESS`;
export const requestFail = (type: string) => `${type}_FAIL`;
