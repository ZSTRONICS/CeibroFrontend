import { InvitationInterface } from "./interfaces/invitation.interface";

export const INVITATIONS_LIST: InvitationInterface[] = [
  // {
  //     name: 'Kristo Vunukainen',
  //     time: "10:25 PM"
  // },
  // {
  //     name: 'Indrek Ilum',
  //     time: "10:25 PM"
  // },
  // {
  //     name: 'Mart Kivikas',
  //     time: "10:25 PM"
  // },
  // {
  //     name: 'Rene Oruman-Kivist',
  //     time: "10:25 PM"
  // },
  // {
  //     name: 'Kristo Vunukainen',
  //     time: "10:25 PM"
  // },
  // {
  //     name: 'Indrek Ilum',
  //     time: "10:25 PM"
  // },
  // {
  //     name: 'Mart Kivikas',
  //     time: "10:25 PM"
  // },
  // {
  //     name: 'Rene Oruman-Kivist',
  //     time: "10:25 PM"
  // },
  // {
  //     name: 'Kristo Vunukainen',
  //     time: "10:25 PM"
  // },
  // {
  //     name: 'Indrek Ilum',
  //     time: "10:25 PM"
  // },
  // {
  //     name: 'Mart Kivikas',
  //     time: "10:25 PM"
  // },
  // {
  //     name: 'Rene Oruman-Kivist',
  //     time: "10:25 PM"
  // }
];
