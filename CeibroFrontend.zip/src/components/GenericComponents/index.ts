import GenericMenu from "./GenericMenu";
import InputSearch from "./InputSearch";

export { GenericMenu, InputSearch };

