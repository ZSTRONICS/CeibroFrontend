function DrawingSideBar() {
  return <div>DrawingSideBar</div>;
}

export default DrawingSideBar;
