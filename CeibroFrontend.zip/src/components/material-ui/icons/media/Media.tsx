import { Fragment } from 'react'

export function MediaIcon(props: any) {
    return (
        <Fragment>


            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M10.5 4H11.5M15 9.99347L12 6.99543L9 9.99347L5 4.99673L1 9.99999M2 1H14C14.5523 1 15 1.44772 15 2V14C15 14.5523 14.5523 15 14 15H2C1.44772 15 1 14.5523 1 14V2C1 1.44772 1.44772 1 2 1Z" stroke="#0075D0" strokeWidth="1.5" />
            </svg>


        </Fragment>
    )
}
