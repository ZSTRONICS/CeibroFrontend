import React from "react";

export default function FilterTabs() {
  return <div>index</div>;
}
