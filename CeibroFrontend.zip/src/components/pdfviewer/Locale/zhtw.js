/*
** Default theme and style for the widget
** Terry Chan
** 11/04/2019
*/
export const GREY1BG = '#eeeeee';
export const FRONTSIZE = '12px';

