export type selectedTaskFilterType =
  | "allTaskFromMe"
  | "allTaskToMe"
  | "allTaskHidden"
  | "tasks"
  | "projects"
  | "locations"
  | "newTask"
  | "newProject";
