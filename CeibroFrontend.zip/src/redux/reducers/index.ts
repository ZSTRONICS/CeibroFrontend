export * from './appReducer'
export * from './auth.reducer'
export * from './docs.reducer'
export * from './project.reducer'
export { default as rootReducer } from "./root.reducer"
export * from './task.reducer'
export * from './user.reducer'

