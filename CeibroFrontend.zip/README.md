# README #

1. Install Node js latest version

2. install React.js latest version

3. clone this project.

4. After clone open this project in terminal

5. enter 'npm install' in root of this project

6. Once above command completed, Run 'npm start'

7. Project will run over 3000 port